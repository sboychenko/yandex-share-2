=== Plugin Name ===
Contributors: sboychenko
Donate link: http://bserg.ru/
Tags: share, social, yandex, twitter, facebook, vkontakte, gplus
Requires at least: 4.4
Tested up to: 4.7
Stable tag: 0.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Блок "Поделиться" от Яндекса версии 2. Позволяет быстро добавить и настроить блок клавиш, выводимы во всех постах

== Description ==

Позволит добавить блок "Поделиться" от Яндекса в каждую запись.
Все настройки можно осуществить в административной панеле плагина.
В настоящее время поддерживается обмен ссылками с пользователями следующих социальных сетей:
* blogger — Blogger;
* collections — Яндекс.Коллекции;
* delicious — Delicious;
* digg — Digg;
* evernote — Evernote;
* facebook — Facebook;
* gplus — Google+;
* linkedin — LinkedIn;
* lj — Живой Журнал;
* moimir — Мой Мир;
* odnoklassniki — Одноклассники.ru;
* pinterest — Pinterest (требуется указать атрибут data-image);
* pocket — Pocket;
* qzone — Qzone;
* reddit — Reddit;
* renren — Renren;
* sinaWeibo — Sina Weibo;
* skype — Skype;
* surfingbird — Surfingbird;
* telegram — Telegram;
* tencentWeibo — Tencent Weibo;
* tumblr — Tumblr;
* twitter — Twitter;
* viber — Viber;
* vkontakte — ВКонтакте;
* whatsapp — WhatsApp.

Более про параметры можно прочитать на [сайте яндекса](https://tech.yandex.ru/share/doc/dg/add-docpage/)

== Installation ==

1. Распакуйте архив с плагином
2. Загрузите папку с плагином в директорию `/wp-content/plugins/` на вашем сервере
3. Активируйте плагин Блок "Поделиться" в разделе Плагины в панели администрирования WordPress
4. Зайдите в раздел Настройки - Блок "Поделиться" для конфигурации

== Frequently Asked Questions ==

== Screenshots ==

1. Внешний вид блока в записи
2. настройки в административной панеле

== Changelog ==

= 0.1 =
* first version