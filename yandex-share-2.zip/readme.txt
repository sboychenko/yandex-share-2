Plugin for WordPress. Add Yandex.Share (Яндекс Блок "Поледиться") to posts
https://tech.yandex.ru/share/

== ver 0.1.0
first version
